﻿
using System.ComponentModel.DataAnnotations;

namespace CMCS.Web.Models
{
    public class Claim
    {
        public int Id { get; set; }

        [Required]
        public string LecturerId { get; set; } = string.Empty;

        public DateTime SubmissionDate { get; set; }

        public decimal HoursWorked { get; set; }

        public decimal HourlyRate { get; set; }

        public decimal TotalAmount { get; set; }

        [Required]
        public string Status { get; set; } = "Pending";

        public string? Notes { get; set; }

        public string? SupportingDocumentPath { get; set; }

        public virtual ApplicationUser? Lecturer { get; set; }

        public virtual ICollection<ClaimApproval>? Approvals { get; set; }
    }
}
