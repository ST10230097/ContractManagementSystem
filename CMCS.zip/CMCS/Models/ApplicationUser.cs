﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace CMCS.Web.Models
{
    public class ApplicationUser : IdentityUser
    {
        [Required]
        public string FullName { get; set; } = string.Empty;

        [Required]
        public string Role { get; set; } = string.Empty;

        public virtual ICollection<Claim>? Claims { get; set; }

        public virtual ICollection<ClaimApproval>? Approvals { get; set; }
    }
}