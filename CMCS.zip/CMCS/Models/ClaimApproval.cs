﻿using System.ComponentModel.DataAnnotations;

namespace CMCS.Web.Models
{
    public class ClaimApproval
    {
        public int Id { get; set; }

        public int ClaimId { get; set; }

        [Required]
        public string ApproverId { get; set; } = string.Empty;

        [Required]
        public string ApproverRole { get; set; } = string.Empty;

        public DateTime ApprovalDate { get; set; }

        [Required]
        public string Status { get; set; } = string.Empty;

        public string? Comments { get; set; }

        public virtual Claim? Claim { get; set; }

        public virtual ApplicationUser? Approver { get; set; }
    }
}
