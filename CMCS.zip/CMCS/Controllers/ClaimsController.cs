﻿using CMCS.Data;
using CMCS.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace CMCS.Controllers
{
    public class ClaimsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _environment;
        private readonly UserManager<ApplicationUser> _userManager;

        public ClaimsController(
            ApplicationDbContext context,
            IWebHostEnvironment environment,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _environment = environment;
            _userManager = userManager;
        }

        [HttpGet]
        public async Task<IActionResult> Submit()
        {
            return View(new ClaimSubmissionViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Submit(ClaimSubmissionViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var user = await _userManager.GetUserAsync(User);

            var claim = new Claim
            {
                LecturerId = user.Id,
                SubmissionDate = DateTime.UtcNow,
                HoursWorked = model.HoursWorked,
                HourlyRate = model.HourlyRate,
                TotalAmount = model.HoursWorked * model.HourlyRate,
                Status = "Pending",
                Notes = model.Notes
            };

            if (model.SupportingDocument != null)
            {
                var fileName = Path.GetRandomFileName() + Path.GetExtension(model.SupportingDocument.FileName);
                var filePath = Path.Combine(_environment.WebRootPath, "uploads", fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await model.SupportingDocument.CopyToAsync(stream);
                }

                claim.SupportingDocumentPath = fileName;
            }

            _context.Claims.Add(claim);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public async Task<IActionResult> Review()
        {
            var user = await _userManager.GetUserAsync(User);
            var claims = await _context.Claims
                .Include(c => c.Lecturer)
                .Include(c => c.Approvals)
                .Where(c => c.Status == "Pending")
                .ToListAsync();

            return View(claims);
        }

        [HttpPost]
        public async Task<IActionResult> Approve(int id, string status, string comments)
        {
            var claim = await _context.Claims.FindAsync(id);
            var user = await _userManager.GetUserAsync(User);

            var approval = new ClaimApproval
            {
                ClaimId = id,
                ApproverId = user.Id,
                ApproverRole = user.Role,
                ApprovalDate = DateTime.UtcNow,
                Status = status,
                Comments = comments
            };

            claim.Status = status;
            _context.ClaimApprovals.Add(approval);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Review));
        }
    }
}
